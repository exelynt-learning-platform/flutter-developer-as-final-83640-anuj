import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/theme/theme_provider.dart';
import '../../../../core/widgets/state_views.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../domain/entities/employee_entity.dart';
import '../providers/employee_provider.dart';
import '../widgets/employee_card.dart';
import '../widgets/filter_sheet.dart';
import 'employee_detail_screen.dart';
import 'employee_form_screen.dart';

/// Protected landing screen: the employee list with search, filter, CRUD and
/// pull-to-refresh, shown once a user is authenticated.
class EmployeeListScreen extends StatefulWidget {
  const EmployeeListScreen({super.key});

  @override
  State<EmployeeListScreen> createState() => _EmployeeListScreenState();
}

class _EmployeeListScreenState extends State<EmployeeListScreen> {
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<EmployeeProvider>().fetchEmployees();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _confirmLogout(AuthProvider auth) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Log out'),
        content: const Text('Are you sure you want to log out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Log out'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await auth.logOut();
    }
  }

  Future<void> _confirmDelete(EmployeeProvider provider, EmployeeEntity employee) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete employee'),
        content: Text('Are you sure you want to delete ${employee.name}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.error),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final success = await provider.removeEmployee(employee.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success ? '${employee.name} deleted' : provider.errorMessage ?? 'Delete failed',
        ),
      ),
    );
  }

  Future<void> _openFilterSheet(EmployeeProvider provider) async {
    final result = await showEmployeeFilterSheet(
      context,
      initialField: provider.filterField,
      initialQuery: provider.filterQuery,
    );
    if (result != null) {
      provider.setFilter(result.field, result.query);
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<EmployeeProvider>();
    final auth = context.watch<AuthProvider>();
    final themeProvider = context.watch<ThemeProvider>();
    final isDark = themeProvider.themeMode == ThemeMode.dark ||
        (themeProvider.themeMode == ThemeMode.system &&
            MediaQuery.platformBrightnessOf(context) == Brightness.dark);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Employees'),
        actions: [
          IconButton(
            icon: Icon(isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
            tooltip: 'Toggle theme',
            onPressed: themeProvider.toggleTheme,
          ),
          IconButton(
            icon: Badge(
              isLabelVisible: provider.filterField != null && provider.filterQuery.isNotEmpty,
              child: const Icon(Icons.filter_list),
            ),
            tooltip: 'Filter',
            onPressed: () => _openFilterSheet(provider),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Log out',
            onPressed: () => _confirmLogout(auth),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: TextField(
              controller: _searchController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'Search employee by ID',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                suffixIcon: provider.isSearchingById
                    ? IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          _searchController.clear();
                          provider.clearSearch();
                        },
                      )
                    : null,
              ),
              onSubmitted: (value) => provider.searchById(value),
            ),
          ),
          Expanded(child: _buildBody(provider)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'Add employee',
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const EmployeeFormScreen()),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBody(EmployeeProvider provider) {
    if (provider.isSearchingById) {
      if (provider.isSearchInFlight) return const LoadingView();
      if (provider.searchResult != null) {
        final employee = provider.searchResult!;
        return ListView(
          padding: const EdgeInsets.only(top: 8, bottom: 96),
          children: [
            EmployeeCard(
              employee: employee,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => EmployeeDetailScreen(employee: employee)),
              ),
              onEdit: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => EmployeeFormScreen(employee: employee)),
              ),
              onDelete: () => _confirmDelete(provider, employee),
            ),
          ],
        );
      }
      return EmptyView(message: provider.searchError ?? 'No employee found', icon: Icons.search_off);
    }

    switch (provider.status) {
      case EmployeeListStatus.initial:
      case EmployeeListStatus.loading:
        return const LoadingView();
      case EmployeeListStatus.error:
        return ErrorView(
          message: provider.errorMessage ?? 'Something went wrong',
          onRetry: provider.fetchEmployees,
        );
      case EmployeeListStatus.loaded:
        final employees = provider.employees;
        return RefreshIndicator(
          onRefresh: provider.refresh,
          child: Column(
            children: [
              if (provider.isShowingCache && provider.errorMessage != null)
                Container(
                  width: double.infinity,
                  color: Theme.of(context).colorScheme.errorContainer,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Text(
                    provider.errorMessage!,
                    style: TextStyle(color: Theme.of(context).colorScheme.onErrorContainer),
                  ),
                ),
              Expanded(
                child: employees.isEmpty
                    ? ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: const [
                          SizedBox(height: 120),
                          EmptyView(message: 'No employees found'),
                        ],
                      )
                    : ListView.builder(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.only(top: 8, bottom: 96),
                        itemCount: employees.length,
                        itemBuilder: (context, index) {
                          final employee = employees[index];
                          return EmployeeCard(
                            employee: employee,
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => EmployeeDetailScreen(employee: employee),
                              ),
                            ),
                            onEdit: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => EmployeeFormScreen(employee: employee),
                              ),
                            ),
                            onDelete: () => _confirmDelete(provider, employee),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
    }
  }
}
